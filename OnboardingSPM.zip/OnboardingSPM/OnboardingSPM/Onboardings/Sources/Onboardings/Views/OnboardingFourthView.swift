
import SwiftUI

public struct OnboardingFourthView: View {
    let onNext: () -> Void
    
    public init(onNext: @escaping () -> Void) {
        self.onNext = onNext
    }
    
    @State private var selectedAge: Int? = nil
    
    private let ages = Array(1...100)
    private let itemHeight: CGFloat = 58.0
    
    
    public var body: some View {
        GeometryReader { geometry in
            let screenHeight = geometry.size.height
            let screenWidth = geometry.size.width
            ZStack {
                Color.appBackground.ignoresSafeArea()
                AppGradient.lightScrim.ignoresSafeArea()
                
                VStack(spacing: 0) {
                    Text("What is your age?")
                        .font(.interMedium(size: 36))
                        .foregroundStyle(Color.white)
                        .multilineTextAlignment(.leading)
                        .padding(.top, 16)
                        .padding(.leading, 16)
                        .frame(maxWidth: .infinity, alignment: .leading)
                    Spacer()
                    // Кастомный пикер с линиями
                    ZStack {
                        // Линия сверху
                        VStack {
                            Rectangle()
                                .fill(AppGradient.pickerFadeHorizontal)
                                .frame(height: 1)
                                .padding(.horizontal, 10)
                            
                            Spacer()
                            
                            // Линия снизу
                            Rectangle()
                                .fill(AppGradient.pickerFadeHorizontal)
                                .frame(height: 1)
                                .padding(.horizontal, 10)
                        }
                        .frame(height: itemHeight)
                        
                        AgePicker(selectedIndex: $selectedAge, items: ages)
                            .frame(height: itemHeight * 7)
                    }
                    .frame(height: itemHeight * 5)
                    
                    Spacer()
                    Button {
                        onNext()
                    } label: {
                        Text("Continue")
                            .foregroundStyle(.white)
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(PrimaryButtonStyle())
                    .padding(.horizontal, screenWidth * 0.04)
                    .padding(.bottom, screenHeight * 0.01)
                }
            }
        }
        
    }
}

public struct AgePicker: View {
    @Binding var selectedIndex: Int?
    public var items: [Int]
    public var itemHeight: CGFloat = 58.0
    
    public init(selectedIndex: Binding<Int?>, items: [Int], itemHeight: CGFloat = 58.0) {
        self._selectedIndex = selectedIndex
        self.items = items
        self.itemHeight = itemHeight
    }
    
    public var body: some View {
        ZStack {
            ScrollView(.vertical) {
                LazyVStack(spacing: 0) {
                    ForEach(0..<items.count, id: \.self) { index in
                        let age = items[index]
                        let isSelected = selectedIndex == index
                        
                        let backgroundView: some View = {
                            if isSelected {
                                return AnyView(
                                    RoundedRectangle(cornerRadius: 8)
                                        .fill(Color.clear)
                                )
                            } else {
                                return AnyView(Color.clear)
                            }
                        }()
                        
                        Text("\(age)")
                            .font(.title2)
                            .fontWeight(isSelected ? .bold : .regular)
                            .foregroundColor(isSelected ? .white : .white.opacity(0.6))
                            .frame(height: itemHeight)
                            .frame(maxWidth: .infinity)
                            .background(backgroundView)
                            .id(index)
                    }
                }
                .scrollTargetLayout()
            }
            .scrollPosition(id: $selectedIndex, anchor: .center)
            .scrollTargetBehavior(.viewAligned)
            .scrollIndicators(.hidden)
            .background(Color.clear)
            .mask(
                LinearGradient(
                    gradient: Gradient(
                        stops: [
                            .init(color: .clear, location: 0),
                            .init(color: .black, location: 0.35),
                            .init(color: .black, location: 0.65),
                            .init(color: .clear, location: 1)
                        ]
                    ),
                    startPoint: .top,
                    endPoint: .bottom
                )
            )
        }
    }
}

