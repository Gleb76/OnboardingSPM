//
//  OnboardingSPMApp.swift
//  OnboardingSPM
//
//  Created by Глеб Клыга on 21.09.25.
//

import SwiftUI

@main
struct OnboardingSPMApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
